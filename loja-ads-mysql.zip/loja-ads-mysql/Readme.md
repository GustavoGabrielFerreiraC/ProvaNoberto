*Trabalho De Eduardo é Gustavo Gabriel*


# Loja ADS — anotações do projeto (2º módulo)

Esse é o projeto que eu montei pro 2º módulo de **Análise e Desenvolvimento de Sistemas**.
Resumo rápido: é uma lojinha com uma página pública (o cliente vê e pesquisa os produtos)
e um painel de admin com login (eu cadastro, edito e excluo as paradas).

Fiz em **PHP + MySQL** (com `mysqli`) e **Bootstrap 5** no painel. O CSS e o JavaScript
fui eu que escrevi na mão, sem framework, porque era isso que a matéria pedia.

## Como tá o projeto hoje

Tá tudo rodando, do começo ao fim:

- a loja lista os produtos do banco, com foto, categoria, preço e os detalhes;
- a pesquisa filtra por nome e por categoria usando `GET` (dá pra ver os filtros na URL);
- o login confere a senha criptografada com `password_verify`;
- toda página do painel é protegida pela sessão (`verifica_login.php`);
- os três CRUDs (produtos, categorias e usuários) estão completos;
- o upload da imagem tem validação no navegador e no servidor, e mostra prévia;
- o fundo de céu noturno animado aparece na loja e no painel.

O login do painel é **admin** / **admin123** (já vem cadastrado no `banco.sql`).

## O que tem em cada pasta

```
loja_ads/
├── index.php            a loja (lista + pesquisa)
├── conexao.php          conexão com o banco
├── fundo_ceu.php        o céu animado que fica atrás de tudo
├── estilo.css           todo o CSS do site e do painel
├── banco.sql            script que cria o banco e as tabelas
├── js/animacoes.js      as animações da loja (DOM)
├── fonts/               fonte HalloweenBones (só nos títulos da loja)
├── imagens/             onde o upload salva as fotos
└── admin/
    ├── login.php        tela de login
    ├── logout.php       encerra a sessão
    ├── verifica_login.php  barra quem não fez login
    ├── menu.php         menu do painel
    ├── index.php        painel com contadores e últimos produtos
    ├── js/animacoes.js  animações do painel + validação da imagem
    ├── produtos/        listar.php e form.php
    ├── categorias/      listar.php e form.php
    └── usuarios/        listar.php e form.php
```

## Banco de dados

O banco chama `loja` e tem três tabelas:

| Tabela | Pra que serve |
| --- | --- |
| `usuarios` | nome, login e senha (criptografada com `password_hash`) de quem entra no painel |
| `categorias` | o nome das categorias dos produtos |
| `produtos` | nome, descrição, características, peso, largura, altura, profundidade, preço e imagem |

A tabela `produtos` tem uma **chave estrangeira** (`categoria_id`) apontando pra
`categorias`, então produto sem categoria não entra.

Quem ensinou essa parte foi o **professor Willian**. Foi ele que mostrou o `CREATE DATABASE`,
os tipos certos de cada campo (`VARCHAR`, `TEXT`, `DECIMAL`, `INT AUTO_INCREMENT`), a chave
primária, a chave estrangeira e o porquê de `DECIMAL(10,2)` pra dinheiro. E também a nunca
guardar senha em texto puro. A parte de banco é toda em cima das aulas dele.

## CRUD (o Create, Read, Update, Delete)

O CRUD foi o **professor Noberto** que ensinou. Cada coisa tem duas páginas:

- `listar.php` — **Read** e **Delete**: mostra tudo numa tabela do Bootstrap e o botão de
  excluir manda `?excluir=ID` na URL;
- `form.php` — **Create** e **Update**: é o mesmo formulário pra cadastrar e editar. Quando
  a URL tem `?id=...`, o PHP busca o registro no banco e preenche os campos.

Umas coisas que peguei nas aulas e uso até hoje:

- `mysqli_real_escape_string` antes de jogar texto no SQL, pra evitar SQL Injection;
- `(int)` nos IDs que vêm pela URL;
- `INSERT` pra cadastrar, `UPDATE ... WHERE id=` pra editar e `DELETE ... WHERE id=` pra apagar;
- `header("Location: listar.php")` depois de salvar, senão duplica o cadastro no F5;
- `INNER JOIN` pra mostrar o nome da categoria junto do produto;
- umas regrinhas: não deixa excluir categoria que tem produto, e o usuário logado não pode
  excluir a própria conta.

Senha de usuário vai com `password_hash()` e o login confere com `password_verify()`.

## Manipulação de imagens

O upload fica em `admin/produtos/form.php` e a prévia em `admin/js/animacoes.js`.
Quando escolho a foto do produto, rola assim:

1. **Prévia antes de salvar** — o JavaScript lê o arquivo com `FileReader` e troca o `src`
   de uma `<img>`, aí dá pra ver a foto antes de enviar.
2. **Validação no navegador** — o JS confere o tipo (`image/jpeg`, `image/png`, `image/gif`,
   `image/webp`) e o tamanho máximo de **2 MB**. Se errar, aparece uma mensagem embaixo do
   campo e o arquivo é limpo.
3. **Validação no servidor** — o PHP confere extensão e tamanho de novo
   (`$_FILES["imagem"]["size"]`), porque validação só no JS dá pra burlar.
4. **Salvamento** — o arquivo vai pra pasta `imagens/` com nome único
   (`time() . "." . $extensao`) e só o nome dele fica no banco (`move_uploaded_file`).
5. **Exclusão** — quando excluo o produto, o `unlink()` apaga a imagem da pasta também,
   senão fica um monte de foto perdida ocupando espaço.

A prévia e a validação da imagem eu aprendi com os vídeos do canal **Celke**.

## Manipulação do DOM e as animações

DOM foi o **professor Proti** que ensinou. Não usei jQuery, é JavaScript puro mexendo nos
elementos da página.

Na loja (`js/animacoes.js`):

- o título entra animando `opacity` e `margin-top`;
- os cards dos produtos aparecem um depois do outro, com `setTimeout` calculando o atraso
  pela posição de cada card.

No painel (`admin/js/animacoes.js`):

- os cards sobem na entrada e depois eu limpo o estilo inline, senão o `:hover` do CSS não
  funciona mais;
- o clique nos botões cria um `<span class="ripple">` no ponto do mouse (efeito de onda);
- o link de excluir pede confirmação no `confirm()` e cancela o clique se eu disser não;
- o upload mostra a prévia e as mensagens de erro, como falei ali em cima.

O fundo de céu (estrelas piscando, estrelas cadentes e a lua) também é animação, feita com
`@keyframes` no CSS, e aparece na loja e no painel pelo `fundo_ceu.php`. A base dele eu peguei
pronta no Uiverse (explico ali embaixo).

## O que eu peguei pronto (Uiverse.io)

Não vou fingir que fiz tudo do zero: parte do visual eu peguei no site **Uiverse.io**
(https://uiverse.io), que é um site onde o pessoal posta componente de HTML e CSS pra usar de
graça. Eu peguei o código, colei no projeto e fui mexendo até ficar do jeito que eu queria.

O que veio de lá:

- **o fundo de céu noturno** (estrelas piscando, estrelas cadentes e a lua) — peguei o exemplo
  do autor `kiranmayee-abbireddy`, que é licença MIT, e adaptei pra virar uma camada fixa
  atrás do site inteiro (`fundo_ceu.php` + o `@keyframes` no `estilo.css`);
- **o efeito de onda (ripple) dos botões do painel** — aquela ondinha que sai do ponto onde
  clica. O CSS do `.ripple` e do `@keyframes ripple-animation` é o do exemplo; a parte de
  JavaScript (criar o `<span>` no ponto do clique) fui eu que fiz na aula de DOM.

A ideia era essa mesmo: o **Uiverse** me deu a parte visual pronta, e eu usei o que aprendi de
DOM, CSS e PHP pra encaixar isso no projeto e fazer funcionar junto com o resto. Vale a pena
falar isso na apresentação, porque mostra que eu sei procurar referência e adaptar, e não só
copiar.

## Quem me ensinou e os vídeos que usei

A base veio das aulas, e o resto eu completei com vídeo de professor no YouTube.

**Nas aulas:**

- **Professor Willian** — banco de dados: banco, tabelas, chaves e relacionamento.
- **Professor Noberto** — CRUD em PHP com MySQL.
- **Professor Proti** — manipulação do DOM com JavaScript.

**Vídeos que usei pra tirar dúvida:**

| Professor / canal | Vídeo | O que peguei |
| --- | --- | --- |
| Professor Edson Maia | “Curso de JS Aula 08 DOM Manipular HTML com o JavaScript” | selecionar elemento, mudar conteúdo e estilo (DOM) |
| Professor Eliel Cruz | “Como fazer CRUD com PHP e MySQL do ZERO” | cadastrar, listar, editar e excluir com PHP e MySQL |
| Celke (Cesar Szpak) | “Como fazer upload de imagem com PHP” | upload, nome único do arquivo e salvar na pasta |
| Celke (Cesar Szpak) | “Como validar múltiplas imagens com JavaScript” | validar tipo e tamanho da imagem |
| Professor Aylton Inácio | “Curso de MySQL e SQL para iniciantes — 17 aulas — COMPLETO!” | revisão de SQL, tabelas e consultas |

Links:

- https://www.youtube.com/watch?v=0dBY09OJm04
- https://www.youtube.com/watch?v=BSqtIw_hW8M
- https://www.youtube.com/watch?v=NIEjVB8okds
- https://www.youtube.com/watch?v=757uEBs7FHQ
- https://www.youtube.com/watch?v=eMPsLoIlNoc
