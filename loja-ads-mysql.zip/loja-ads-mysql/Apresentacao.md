# Loja ADS — apresentação

Projeto do 2º módulo de ADS: uma loja em **PHP + MySQL**, com site público e painel admin.

## O que é

- **Loja** (`index.php`): lista os produtos com foto, categoria, preço e detalhes, e tem
  pesquisa por nome e categoria.
- **Painel** (`admin/`): login com senha criptografada, contadores e CRUD de produtos,
  categorias e usuários.

## O que eu quero mostrar

1. **CRUD completo** — cadastrar, listar, editar e excluir nas três tabelas, com chave
   estrangeira entre produto e categoria.
2. **Manipulação de imagens** — upload com prévia antes de salvar, validação de tipo e
   tamanho (2 MB) no navegador e no servidor, e exclusão do arquivo junto com o produto.
3. **Manipulação do DOM** — animações em JavaScript puro: título e cards entrando na loja,
   efeito de onda nos botões, confirmação de exclusão e prévia da imagem no painel.
4. **Visual** — fundo de céu noturno animado (CSS) na loja e no painel.

## Tecnologias

PHP, MySQL (`mysqli`), Bootstrap 5, CSS, JavaScript e XAMPP.

## Quem me ensinou

- **Professor Willian** — banco de dados.
- **Professor Noberto** — CRUD.
- **Professor Proti** — manipulação do DOM.

Completei com vídeos de professores: Edson Maia (DOM), Eliel Cruz (CRUD em PHP/MySQL) e
Celke (upload e validação de imagem). Os detalhes e os links estão no `Readme.md`.

## Pra testar na hora

1. Ligar Apache e MySQL no XAMPP.
2. Importar o `banco.sql`.
3. Abrir `http://localhost/loja_ads/`.
4. Entrar no painel com **admin / admin123**.

Sugestão de roteiro: abrir a loja, pesquisar um produto, logar no painel, cadastrar um
produto com imagem (mostrando a prévia e um arquivo inválido de propósito), editar,
excluir e voltar na loja pra ver o resultado.
