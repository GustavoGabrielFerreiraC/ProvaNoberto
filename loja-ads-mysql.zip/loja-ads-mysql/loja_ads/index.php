<?php
// index.php - a vitrine da loja: mostra os produtos e deixa pesquisar
include "conexao.php";

// pego o que a pessoa digitou na busca (se não digitou nada, fica vazio)
$busca = "";
if (isset($_GET["busca"])) {
    $busca = mysqli_real_escape_string($conexao, $_GET["busca"]); // escapo o texto pra ninguém injetar SQL
}
$categoria = 0;
if (isset($_GET["categoria"])) {
    $categoria = (int)$_GET["categoria"]; // (int) na marra pra garantir que é número
}

// vou montando o SQL: começo com "WHERE 1" e vou colando os filtros
$sql = "SELECT produtos.*, categorias.nome AS categoria
        FROM produtos
        INNER JOIN categorias ON categorias.id = produtos.categoria_id
        WHERE 1";
if ($busca != "") {
    $sql = $sql . " AND produtos.nome LIKE '%$busca%'";
}
if ($categoria > 0) {
    $sql = $sql . " AND produtos.categoria_id = $categoria";
}
$sql = $sql . " ORDER BY produtos.nome";

$produtos = mysqli_query($conexao, $sql);
$categorias = mysqli_query($conexao, "SELECT * FROM categorias ORDER BY nome");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Minha Loja</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body class="loja">
    <?php include "fundo_ceu.php"; ?>

    <div class="pagina">
        <h1>Minha Loja</h1>
        <p><a class="botao-admin" href="admin/login.php">Area administrativa</a></p>

        <!-- busca: usei GET pra dar pra ver os filtros na URL -->
        <form method="get" action="index.php">
            <input type="text" name="busca" placeholder="Nome do produto" value="<?php echo htmlspecialchars(isset($_GET["busca"]) ? $_GET["busca"] : ""); ?>">
            <select name="categoria">
                <option value="0">Todas as categorias</option>
                <?php while ($c = mysqli_fetch_assoc($categorias)) { ?>
                    <option value="<?php echo $c["id"]; ?>" <?php if ($c["id"] == $categoria) echo "selected"; ?>>
                        <?php echo htmlspecialchars($c["nome"]); ?>
                    </option>
                <?php } ?>
            </select>
            <button type="submit">Pesquisar</button>
        </form>
        <hr>

        <div class="produtos">
        <?php
        // esse bloco se repete pra cada produto que veio do banco
        while ($p = mysqli_fetch_assoc($produtos)) { ?>
            <div class="produto">
                <?php if ($p["imagem"] != "") { ?>
                    <img src="imagens/<?php echo $p["imagem"]; ?>" alt="">
                <?php } ?>
                <small><?php echo htmlspecialchars($p["categoria"]); ?></small>
                <h3><?php echo htmlspecialchars($p["nome"]); ?></h3>
                <p><?php echo htmlspecialchars($p["descricao"]); ?></p>
                <b>R$ <?php echo number_format($p["preco"], 2, ",", "."); ?></b>
                <details>
                    <summary>Mais detalhes</summary>
                    <p><?php echo nl2br(htmlspecialchars($p["caracteristicas"])); ?></p>
                    <p>Peso: <?php echo $p["peso"]; ?> kg<br>
                       Largura: <?php echo $p["largura"]; ?> cm<br>
                       Altura: <?php echo $p["altura"]; ?> cm<br>
                       Profundidade: <?php echo $p["profundidade"]; ?> cm</p>
                </details>
            </div>
        <?php } ?>
        </div>

        <?php if (mysqli_num_rows($produtos) == 0) { echo "<p>Nenhum produto encontado.</p>"; } ?>
    </div>

    <!-- as animações ficam nesse arquivo JS (manipulação do DOM) -->
    <script src="js/animacoes.js"></script>
</body>
</html>
