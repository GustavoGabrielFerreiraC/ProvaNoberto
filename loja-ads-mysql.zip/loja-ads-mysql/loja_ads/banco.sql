-- banco da loja, do jeito que o professor Willian mostrou em aula
-- aqui tem o CREATE DATABASE, as tabelas e as chaves
CREATE DATABASE IF NOT EXISTS loja CHARACTER SET utf8mb4;
USE loja;

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(50) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL
);

CREATE TABLE categorias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL
);

CREATE TABLE produtos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  categoria_id INT NOT NULL,
  nome VARCHAR(150) NOT NULL,
  descricao TEXT,
  caracteristicas TEXT,
  peso DECIMAL(8,3),
  largura DECIMAL(8,2),
  altura DECIMAL(8,2),
  profundidade DECIMAL(8,2),
  preco DECIMAL(10,2) NOT NULL,
  imagem VARCHAR(255),
  FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

-- primeiro usuário: login admin, senha admin123 (já com o hash)
INSERT INTO usuarios (nome, login, senha) VALUES ('Administrador', 'admin', '$6$tuK3zBGH5y7K7NMP$gtmKAGWiO1aJ6CocIATYxT3B8j04WwgEJd7whX2lIs/QSbCaTj7mtnW3scG6Zt7O1wGOTcVbD1KWkCWerFsNt/');

INSERT INTO categorias (nome) VALUES ('Informática'), ('Eletrodomésticos'), ('Celulares');
