<?php
// conexao.php - é aqui que eu entro no banco
// no XAMPP o usuário é "root" e a senha fica vazia mesmo
$conexao = mysqli_connect("localhost", "root", "", "loja");

// se não conectar, mostra o erro e para tudo
if (!$conexao) {
    die("Erro ao conectar: " . mysqli_connect_error());
}

// sem isso os acentos viram bagunça na tela
mysqli_set_charset($conexao, "utf8mb4");
