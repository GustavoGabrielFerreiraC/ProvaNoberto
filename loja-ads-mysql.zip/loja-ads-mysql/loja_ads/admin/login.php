<?php
// login.php - a tela de login do painel
session_start();
include "../conexao.php";

$erro = "";

// isso só roda quando o formulário foi enviado (POST)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // pego o que foi digitado
    $login = mysqli_real_escape_string($conexao, $_POST["login"]);
    $senha = $_POST["senha"];

    // procuro o usuário pelo login
    $resultado = mysqli_query($conexao, "SELECT * FROM usuarios WHERE login = '$login'");
    $usuario = mysqli_fetch_assoc($resultado); // vira um array, ou false se não achou

    // password_verify compara a senha digitada com o hash que tá no banco
    if ($usuario && password_verify($senha, $usuario["senha"])) {
        $_SESSION["usuario_id"] = $usuario["id"];     // guardo na sessão
        $_SESSION["usuario_nome"] = $usuario["nome"];
        header("Location: index.php");                // mando pro painel
        exit;
    } else {
        $erro = "Usuário ou senha inválidos.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="../estilo.css">
    <style>
    html, body {
      height: 100%;
      margin: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    /* o fundo escuro vem da classe .fundo-ceu, no estilo.css */
    body.fundo-ceu {
      background: #050505;
    }

    .form {
      --input-focus: #2d8cf0;
      --font-color: #323232;
      --font-color-sub: #666;
      --bg-color: #fff;
      --main-color: #323232;
      padding: 20px;
      background: lightgrey;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      justify-content: center;
      gap: 20px;
      border-radius: 5px;
      border: 2px solid var(--main-color);
      box-shadow: 4px 4px var(--main-color);
    }
    
    .title {
      color: var(--font-color);
      font-weight: 900;
      font-size: 20px;
      margin-bottom: 25px;
    }
    
    .title span {
      color: var(--font-color-sub);
      font-weight: 600;
      font-size: 17px;
    }
    
    .input {
      width: 250px;
      height: 40px;
      border-radius: 5px;
      border: 2px solid var(--main-color);
      background-color: var(--bg-color);
      box-shadow: 4px 4px var(--main-color);
      font-size: 15px;
      font-weight: 600;
      color: var(--font-color);
      padding: 5px 10px;
      outline: none;
    }
    
    .input::placeholder {
      color: var(--font-color-sub);
      opacity: 0.8;
    }
    
    .input:focus {
      border: 2px solid var(--input-focus);
    }
    
    .button-confirm {
      margin: 50px auto 0 auto;
      width: 120px;
      height: 40px;
      border-radius: 5px;
      border: 2px solid var(--main-color);
      background-color: var(--bg-color);
      box-shadow: 4px 4px var(--main-color);
      font-size: 17px;
      font-weight: 600;
      color: var(--font-color);
      cursor: pointer;
    }

    .button-confirm:active {
      box-shadow: 0px 0px var(--main-color);
      transform: translate(3px, 3px);
    }

    .erro {
      color: red;
      font-size: 13px;
      font-weight: 600;
    }
    </style>
</head>
<body class="fundo-ceu">
    <?php include "../fundo_ceu.php"; ?>

    <form class="form" method="post" action="login.php">
      <div class="title">Faça seu Login!,<br><span>Bem-Vindo Admin</span></div>
      
      <?php if ($erro != "") { ?>
        <div class="erro"><?php echo htmlspecialchars($erro); ?></div>
      <?php } ?>
      
      <input type="text" placeholder="Usuario" name="login" class="input" required>
      <input type="password" placeholder="Senha" name="senha" class="input" required>
      <button type="submit" class="button-confirm">Entrar →</button>
    </form>
</body>
</html>
