<?php
// verifica_login.php - coloco no topo de toda página que precisa de login
session_start(); // abre a sessão pra ler o que ficou salvo no login

// se não tem usuario_id na sessão, é porque ninguém logou
if (!isset($_SESSION["usuario_id"])) {
    header("Location: " . $base . "login.php"); // mando de volta pro login
    exit; // e paro o PHP aqui
}
