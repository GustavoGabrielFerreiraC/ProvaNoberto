<!-- menu.php - menu do painel -->
<nav class="admin-menu">
    <div class="admin-menu-container">
        <div class="admin-menu-brand">
            <i class="ph ph-gauge"></i>
            <span>Painel Admin</span>
        </div>
        <div class="admin-menu-links">
            <a href="<?php echo $base; ?>index.php" class="menu-link">
                <i class="ph ph-house"></i>
                <span>Início</span>
            </a>
            <a href="<?php echo $base; ?>produtos/listar.php" class="menu-link">
                <i class="ph ph-package"></i>
                <span>Produtos</span>
            </a>
            <a href="<?php echo $base; ?>categorias/listar.php" class="menu-link">
                <i class="ph ph-tag"></i>
                <span>Categorias</span>
            </a>
            <a href="<?php echo $base; ?>usuarios/listar.php" class="menu-link">
                <i class="ph ph-users"></i>
                <span>Usuários</span>
            </a>
            <a href="../index.php" target="_blank" class="menu-link">
                <i class="ph ph-storefront"></i>
                <span>Ver loja</span>
            </a>
        </div>
        <div class="admin-menu-user">
            <span class="user-info">
                <i class="ph ph-user-circle"></i>
                <?php echo htmlspecialchars($_SESSION["usuario_nome"]); ?>
            </span>
            <a href="<?php echo $base; ?>logout.php" class="menu-link logout-link">
                <i class="ph ph-sign-out"></i>
                <span>Sair</span>
            </a>
        </div>
    </div>
</nav>
