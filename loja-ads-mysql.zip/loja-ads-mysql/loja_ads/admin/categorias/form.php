<?php
// categorias/form.php - cadastrar e editar categoria
$base = "../";
include "../verifica_login.php";
include "../../conexao.php";

$id = 0;
$nome = "";

// se veio ?id=, é edição: busco a categoria pra preencher o campo
if (isset($_GET["id"])) {
    $id = (int)$_GET["id"];
    $r = mysqli_query($conexao, "SELECT * FROM categorias WHERE id = $id");
    $c = mysqli_fetch_assoc($r);
    if ($c) {
        $nome = $c["nome"];
    }
}

// formulário enviado: aí salvo no banco
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = (int)$_POST["id"];
    $nome = $_POST["nome"];
    $nome_sql = mysqli_real_escape_string($conexao, $nome);

    if ($id == 0) {
        mysqli_query($conexao, "INSERT INTO categorias (nome) VALUES ('$nome_sql')");
    } else {
        mysqli_query($conexao, "UPDATE categorias SET nome='$nome_sql' WHERE id=$id");
    }
    header("Location: listar.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ($id == 0) ? "Nova categoria" : "Editar categoria"; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../estilo.css">
</head>
<body class="fundo-ceu">
    <?php include "../../fundo_ceu.php"; ?>
    <?php include "../menu.php"; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="mb-0"><?php echo ($id == 0) ? "Nova categoria" : "Editar categoria"; ?></h1>
            <a href="listar.php" class="btn btn-secondary">← Voltar para lista</a>
        </div>

        <div class="row">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <form method="post">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            
                            <div class="mb-3">
                                <label for="nome" class="form-label">Nome da categoria *</label>
                                <input type="text" class="form-control" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>" required>
                            </div>

                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">Salvar</button>
                                <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/animacoes.js"></script>
</body>
</html>
