<?php
// logout.php - fecha a sessão e volta pro login
session_start();
session_destroy(); // apago tudo que tinha na sessão
header("Location: login.php");
exit;
