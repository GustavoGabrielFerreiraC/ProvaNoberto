// animacoes.js - animações e validações do painel
// é tudo DOM na mão: pego elemento, mudo estilo, crio elemento novo
// e fico escutando os eventos (clique, change...).

// só começo depois que a página terminou de carregar
window.onload = function () {
    animarCards();
    efeitoRipple();
    confirmarExclusao();
    mostrarPreviewImagem();
};

// ---------------------------------------------------------------
// 1) os cards entram um depois do outro
// ---------------------------------------------------------------
function animarCards() {
    var cards = document.querySelectorAll(".card");

    for (var i = 0; i < cards.length; i++) {
        var card = cards[i];

        // deixo invisível e um pouco pra baixo
        card.style.opacity = "0";
        card.style.transform = "translateY(20px)";
        card.style.transition = "opacity 0.4s ease, transform 0.4s ease";

        aparecerCard(card, i);
    }
}

// espero um pouco mais pra cada card, pela posição dele
function aparecerCard(card, posicao) {
    setTimeout(function () {
        card.style.opacity = "1";
        card.style.transform = "translateY(0)";

        // limpo o style inline senão o hover do CSS não funciona
        setTimeout(function () {
            card.style.transform = "";
            card.style.transition = "";
        }, 400);
    }, 150 * posicao);
}

// ---------------------------------------------------------------
// 2) efeito de onda quando clica no botão
// ---------------------------------------------------------------
function efeitoRipple() {
    var botoes = document.querySelectorAll(".btn");

    for (var i = 0; i < botoes.length; i++) {
        botoes[i].addEventListener("click", function (evento) {
            var botao = this;

            // pego o tamanho do botão pra onda sair no tamanho certo
            var tamanho = Math.max(botao.offsetWidth, botao.offsetHeight);
            var posicao = botao.getBoundingClientRect();

            // crio o <span> da onda e coloco dentro do botão
            var onda = document.createElement("span");
            onda.className = "ripple";
            onda.style.width = tamanho + "px";
            onda.style.height = tamanho + "px";
            onda.style.left = (evento.clientX - posicao.left - tamanho / 2) + "px";
            onda.style.top = (evento.clientY - posicao.top - tamanho / 2) + "px";

            botao.appendChild(onda);

            // 600ms depois tiro a onda da página
            setTimeout(function () {
                onda.remove();
            }, 600);
        });
    }
}

// ---------------------------------------------------------------
// 3) pergunta antes de excluir
// ---------------------------------------------------------------
function confirmarExclusao() {
    var links = document.querySelectorAll("a.btn-outline-danger");

    for (var i = 0; i < links.length; i++) {
        links[i].addEventListener("click", function (evento) {
            if (!confirm("Tem certeza que deseja excluir este registro?")) {
                evento.preventDefault(); // cancela o clique
            }
        });
    }
}

// ---------------------------------------------------------------
// 4) prévia e validação da imagem
// ---------------------------------------------------------------
function mostrarPreviewImagem() {
    var campo = document.getElementById("imagem");
    var area = document.getElementById("area-preview");
    var preview = document.getElementById("preview-imagem");
    var aviso = document.getElementById("aviso-imagem");

    // se não achou, é porque não é a página de produto
    if (campo == null || area == null || preview == null) {
        return;
    }

    var formatos = ["image/jpeg", "image/png", "image/gif", "image/webp"];

    campo.addEventListener("change", function () {
        // limpo o que tinha antes
        aviso.innerHTML = "";
        area.style.display = "none";
        preview.src = "";

        var arquivo = campo.files[0];
        if (!arquivo) {
            return;
        }

        // primeira checagem: só aceita imagem
        if (formatos.indexOf(arquivo.type) == -1) {
            aviso.innerHTML = "Escolha uma imagem jpg, png, gif ou webp.";
            campo.value = "";
            return;
        }

        // segunda checagem: no máximo 2 MB
        if (arquivo.size > 2 * 1024 * 1024) {
            aviso.innerHTML = "A imagem pode ter no máximo 2 MB.";
            campo.value = "";
            return;
        }

        // o FileReader lê o arquivo e joga a prévia na tela
        var leitor = new FileReader();
        leitor.onload = function (e) {
            preview.src = e.target.result;
            area.style.display = "block";
        };
        leitor.readAsDataURL(arquivo);
    });
}
