<?php
// produtos/listar.php - mostra os produtos e apaga quando clico em excluir
$base = "../";
include "../verifica_login.php";
include "../../conexao.php";

$msg = "";

if (isset($_GET["excluir"])) {
    $id = (int)$_GET["excluir"];
    // pego o nome da imagem pra apagar o arquivo junto
    $r = mysqli_query($conexao, "SELECT imagem FROM produtos WHERE id = $id");
    $p = mysqli_fetch_assoc($r);
    if ($p && $p["imagem"] != "" && file_exists("../../imagens/" . $p["imagem"])) {
        unlink("../../imagens/" . $p["imagem"]); // e apago o arquivo da pasta imagens
    }
    mysqli_query($conexao, "DELETE FROM produtos WHERE id = $id");
    $msg = "Produto excluído!";
}

// o JOIN traz o nome da categoria junto com o produto
$resultado = mysqli_query($conexao, "SELECT produtos.*, categorias.nome AS categoria
    FROM produtos INNER JOIN categorias ON categorias.id = produtos.categoria_id
    ORDER BY produtos.id DESC");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../../estilo.css">
</head>
<body class="fundo-ceu">
    <?php include "../../fundo_ceu.php"; ?>
    <?php include "../menu.php"; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="mb-0">Produtos</h1>
            <a href="form.php" class="btn btn-primary"><i class="bi bi-plus-circle me-1"></i> Novo produto</a>
        </div>

        <?php if ($msg != "") { ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?php echo htmlspecialchars($msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php } ?>

        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Imagem</th>
                                <th>Nome</th>
                                <th>Categoria</th>
                                <th>Preço</th>
                                <th class="text-center">Açoes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($p = mysqli_fetch_assoc($resultado)) { ?>
                            <tr>
                                <td><?php echo $p["id"]; ?></td>
                                <td>
                                    <?php if ($p["imagem"] != "") { ?>
                                        <img src="../../imagens/<?php echo htmlspecialchars($p["imagem"]); ?>" class="rounded" style="width: 50px; height: 50px; object-fit: cover;">
                                    <?php } else { ?>
                                        <div class="bg-light rounded d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                            <i class="bi bi-image text-muted"></i>
                                        </div>
                                    <?php } ?>
                                </td>
                                <td><strong><?php echo htmlspecialchars($p["nome"]); ?></strong></td>
                                <td><span class="badge bg-secondary-subtle text-secondary"><?php echo htmlspecialchars($p["categoria"]); ?></span></td>
                                <td class="text-success fw-semibold">R$ <?php echo number_format($p["preco"], 2, ",", "."); ?></td>
                                <td class="text-center">
                                    <a href="form.php?id=<?php echo $p["id"]; ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i> Editar</a>
                                    <a href="listar.php?excluir=<?php echo $p["id"]; ?>" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Excluir</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/animacoes.js"></script>
</body>
</html>
