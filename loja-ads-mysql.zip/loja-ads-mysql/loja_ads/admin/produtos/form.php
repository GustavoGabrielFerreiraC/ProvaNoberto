<?php
// produtos/form.php - cadastrar e editar produto (com upload da imagem)
$base = "../";
include "../verifica_login.php";
include "../../conexao.php";

$erro = "";

// o array $p guarda os dados do formulário (começa vazio)
$p = ["id" => 0, "categoria_id" => "", "nome" => "", "descricao" => "", "caracteristicas" => "",
      "peso" => "", "largura" => "", "altura" => "", "profundidade" => "", "preco" => "", "imagem" => ""];

// se veio ?id=, é edição: busco o produto no banco
if (isset($_GET["id"])) {
    $id = (int)$_GET["id"];
    $r = mysqli_query($conexao, "SELECT * FROM produtos WHERE id = $id");
    $achou = mysqli_fetch_assoc($r);
    if ($achou) {
        $p = $achou;
    }
}

// quando o formulário é enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // pego os dados do formulário
    $p["id"] = (int)$_POST["id"];
    $p["categoria_id"] = (int)$_POST["categoria_id"];
    $p["nome"] = $_POST["nome"];
    $p["descricao"] = $_POST["descricao"];
    $p["caracteristicas"] = $_POST["caracteristicas"];
    $p["peso"] = $_POST["peso"];
    $p["largura"] = $_POST["largura"];
    $p["altura"] = $_POST["altura"];
    $p["profundidade"] = $_POST["profundidade"];
    $p["preco"] = $_POST["preco"];
    $p["imagem"] = $_POST["imagem_atual"]; // por padrão fico com a imagem que já existia

    // se escolheram um arquivo (error == 0), faço o upload
    if ($_FILES["imagem"]["error"] == 0) {
        $extensao = strtolower(pathinfo($_FILES["imagem"]["name"], PATHINFO_EXTENSION));
        $tamanho = $_FILES["imagem"]["size"];

        // confiro de novo no servidor: tipo e tamanho (no máximo 2 MB)
        if (!in_array($extensao, ["jpg", "jpeg", "png", "gif", "webp"])) {
            $erro = "A imagem precisa ser jpg, png, gif ou webp.";
        } else if ($tamanho > 2 * 1024 * 1024) {
            $erro = "A imagem pode ter no máximo 2 MB.";
        } else {
            $novo_nome = time() . "." . $extensao; // nome único, uso a hora atual
            move_uploaded_file($_FILES["imagem"]["tmp_name"], "../../imagens/" . $novo_nome);
            $p["imagem"] = $novo_nome;
        }
    }

    if ($erro == "") {
        // escapo os textos e troco vírgula por ponto nos números (19,90 vira 19.90)
        $nome = mysqli_real_escape_string($conexao, $p["nome"]);
        $descricao = mysqli_real_escape_string($conexao, $p["descricao"]);
        $caract = mysqli_real_escape_string($conexao, $p["caracteristicas"]);
        $imagem = mysqli_real_escape_string($conexao, $p["imagem"]);
        $peso = (float)str_replace(",", ".", $p["peso"]);
        $largura = (float)str_replace(",", ".", $p["largura"]);
        $altura = (float)str_replace(",", ".", $p["altura"]);
        $prof = (float)str_replace(",", ".", $p["profundidade"]);
        $preco = (float)str_replace(",", ".", $p["preco"]);
        $cat = $p["categoria_id"];

        if ($p["id"] == 0) {
            $sql = "INSERT INTO produtos (categoria_id, nome, descricao, caracteristicas, peso, largura, altura, profundidade, preco, imagem)
                    VALUES ($cat, '$nome', '$descricao', '$caract', $peso, $largura, $altura, $prof, $preco, '$imagem')";
        } else {
            $sql = "UPDATE produtos SET categoria_id=$cat, nome='$nome', descricao='$descricao', caracteristicas='$caract',
                    peso=$peso, largura=$largura, altura=$altura, profundidade=$prof, preco=$preco, imagem='$imagem'
                    WHERE id=" . $p["id"];
        }
        if (mysqli_query($conexao, $sql)) {
            header("Location: listar.php");
            exit;
        } else {
            $erro = "Erro ao salvar: " . mysqli_error($conexao);
        }
    }
}

// busco as categorias pra montar o <select>
$categorias = mysqli_query($conexao, "SELECT * FROM categorias ORDER BY nome");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ($p["id"] == 0) ? "Novo produto" : "Editar produto"; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../estilo.css">
</head>
<body class="fundo-ceu">
    <?php include "../../fundo_ceu.php"; ?>
    <?php include "../menu.php"; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="mb-0"><?php echo ($p["id"] == 0) ? "Novo produto" : "Editar produto"; ?></h1>
            <a href="listar.php" class="btn btn-secondary">← Voltar para lista</a>
        </div>

        <?php if ($erro != "") { ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($erro); ?></div>
        <?php } ?>

        <div class="card shadow-sm">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $p["id"]; ?>">
                    <input type="hidden" name="imagem_atual" value="<?php echo htmlspecialchars($p["imagem"]); ?>">

                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label for="nome" class="form-label">Nome do produto *</label>
                            <input type="text" class="form-control" id="nome" name="nome" value="<?php echo htmlspecialchars($p["nome"]); ?>" required>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="categoria_id" class="form-label">Categoria *</label>
                            <select class="form-select" id="categoria_id" name="categoria_id" required>
                                <option value="">Selecione...</option>
                                <?php while ($c = mysqli_fetch_assoc($categorias)) { ?>
                                    <option value="<?php echo $c["id"]; ?>" <?php if ($c["id"] == $p["categoria_id"]) echo "selected"; ?>>
                                        <?php echo htmlspecialchars($c["nome"]); ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="descricao" class="form-label">Descrição</label>
                        <textarea class="form-control" id="descricao" name="descricao" rows="3"><?php echo htmlspecialchars($p["descricao"]); ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="caracteristicas" class="form-label">Características</label>
                        <textarea class="form-control" id="caracteristicas" name="caracteristicas" rows="4"><?php echo htmlspecialchars($p["caracteristicas"]); ?></textarea>
                    </div>

                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label for="preco" class="form-label">Preço (R$) *</label>
                            <input type="text" class="form-control" id="preco" name="preco" value="<?php echo $p["preco"]; ?>" placeholder="0,00" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="peso" class="form-label">Peso (kg)</label>
                            <input type="text" class="form-control" id="peso" name="peso" value="<?php echo $p["peso"]; ?>" placeholder="0,000">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label for="largura" class="form-label">Largura (cm)</label>
                            <input type="text" class="form-control" id="largura" name="largura" value="<?php echo $p["largura"]; ?>">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label for="altura" class="form-label">Altura (cm)</label>
                            <input type="text" class="form-control" id="altura" name="altura" value="<?php echo $p["altura"]; ?>">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label for="profundidade" class="form-label">Profundidade (cm)</label>
                            <input type="text" class="form-control" id="profundidade" name="profundidade" value="<?php echo $p["profundidade"]; ?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="imagem" class="form-label">Imagem do produto</label>
                        <input class="form-control" type="file" id="imagem" name="imagem" accept="image/*">
                        <small class="text-muted">Formatos: jpg, png, gif ou webp (até 2 MB).</small>
                        <div id="aviso-imagem"></div>

                        <!-- a prévia quem preenche é o JavaScript (animacoes.js) -->
                        <div id="area-preview" class="mt-2">
                            <small class="text-muted">Previa da nova imagem:</small><br>
                            <img id="preview-imagem" class="img-thumbnail mt-1" alt="Prévia da imagem escolhida">
                        </div>

                        <?php if ($p["imagem"] != "") { ?>
                            <div class="mt-2">
                                <small class="text-muted">Imagem atual:</small><br>
                                <img src="../../imagens/<?php echo htmlspecialchars($p["imagem"]); ?>" class="img-thumbnail mt-1 imagem-atual" alt="Imagem atual do produto">
                            </div>
                        <?php } ?>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">Salvar</button>
                        <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/animacoes.js"></script>
</body>
</html>
