<?php
// index.php do admin - o painel que abre depois do login
$base = "";
include "verifica_login.php";
include "../conexao.php";

// conto quantos registros tem em cada tabela
$qtd_produtos   = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT COUNT(*) AS total FROM produtos"))["total"];
$qtd_categorias = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT COUNT(*) AS total FROM categorias"))["total"];
$qtd_usuarios   = mysqli_fetch_assoc(mysqli_query($conexao, "SELECT COUNT(*) AS total FROM usuarios"))["total"];

// pego os 5 últimos produtos cadastrados
$ultimos = mysqli_query($conexao, "SELECT produtos.*, categorias.nome AS categoria
                                    FROM produtos 
                                    INNER JOIN categorias ON categorias.id = produtos.categoria_id 
                                    ORDER BY produtos.id DESC 
                                    LIMIT 5");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <link rel="stylesheet" href="../estilo.css">
</head>
<body class="fundo-ceu admin-body">
    <?php include "../fundo_ceu.php"; ?>
    <?php include "menu.php"; ?>
    
    <div class="admin-container">
        <div class="mb-4">
            <h1 class="admin-title"><i class="ph ph-gauge me-2"></i>Painel Administrativo</h1>
            <p class="admin-subtitle">Olá, <strong><?php echo htmlspecialchars($_SESSION["usuario_nome"]); ?></strong>! Seja bem-vindo(a) ao painel.</p>
        </div>

        <!-- os cards com os números do painel -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card stat-card-primary h-100">
                    <div class="stat-card-body">
                        <div class="stat-card-info">
                            <p class="stat-card-label">Produtos</p>
                            <h2 class="stat-card-value numero-painel" data-valor="<?php echo $qtd_produtos; ?>"><?php echo $qtd_produtos; ?></h2>
                        </div>
                        <div class="stat-card-icon stat-card-icon-primary">
                            <i class="ph ph-package"></i>
                        </div>
                    </div>
                    <div class="stat-card-footer">
                        <a href="produtos/listar.php" class="stat-card-link">Ver todos <i class="ph ph-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="stat-card stat-card-success h-100">
                    <div class="stat-card-body">
                        <div class="stat-card-info">
                            <p class="stat-card-label">Categorias</p>
                            <h2 class="stat-card-value numero-painel" data-valor="<?php echo $qtd_categorias; ?>"><?php echo $qtd_categorias; ?></h2>
                        </div>
                        <div class="stat-card-icon stat-card-icon-success">
                            <i class="ph ph-tag"></i>
                        </div>
                    </div>
                    <div class="stat-card-footer">
                        <a href="categorias/listar.php" class="stat-card-link">Ver todos <i class="ph ph-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="stat-card stat-card-warning h-100">
                    <div class="stat-card-body">
                        <div class="stat-card-info">
                            <p class="stat-card-label">Usuários</p>
                            <h2 class="stat-card-value numero-painel" data-valor="<?php echo $qtd_usuarios; ?>"><?php echo $qtd_usuarios; ?></h2>
                        </div>
                        <div class="stat-card-icon stat-card-icon-warning">
                            <i class="ph ph-users"></i>
                        </div>
                    </div>
                    <div class="stat-card-footer">
                        <a href="usuarios/listar.php" class="stat-card-link">Ver todos <i class="ph ph-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- atalhos pra cadastrar -->
            <div class="col-lg-4">
                <div class="admin-card h-100">
                    <div class="admin-card-header">
                        <h5 class="admin-card-title"><i class="ph ph-lightning me-2"></i>Ações Rápidas</h5>
                    </div>
                    <div class="admin-card-body d-grid gap-2">
                        <a href="produtos/form.php" class="quick-action-btn quick-action-primary">
                            <div class="quick-action-icon"><i class="ph ph-plus-circle"></i></div>
                            <span>Adicionar novo produto</span>
                            <i class="ph ph-caret-right quick-action-arrow"></i>
                        </a>
                        <a href="categorias/form.php" class="quick-action-btn quick-action-success">
                            <div class="quick-action-icon"><i class="ph ph-plus-circle"></i></div>
                            <span>Adicionar nova categoria</span>
                            <i class="ph ph-caret-right quick-action-arrow"></i>
                        </a>
                        <a href="usuarios/form.php" class="quick-action-btn quick-action-warning">
                            <div class="quick-action-icon"><i class="ph ph-user-plus"></i></div>
                            <span>Adicionar novo usuário</span>
                            <i class="ph ph-caret-right quick-action-arrow"></i>
                        </a>
                        <a href="../index.php" target="_blank" class="quick-action-btn quick-action-dark">
                            <div class="quick-action-icon"><i class="ph ph-storefront"></i></div>
                            <span>Visualizar loja</span>
                            <i class="ph ph-arrow-square-out quick-action-arrow"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- os últimos que cadastrei -->
            <div class="col-lg-8">
                <div class="admin-card h-100">
                    <div class="admin-card-header d-flex justify-content-between align-items-center">
                        <h5 class="admin-card-title"><i class="ph ph-clock-counter-clockwise me-2"></i>Últimos produtos cadastrados</h5>
                        <a href="produtos/listar.php" class="admin-btn admin-btn-sm admin-btn-outline">Ver todos <i class="ph ph-arrow-right"></i></a>
                    </div>
                    <div class="admin-card-body p-0">
                        <div class="table-responsive">
                            <table class="admin-table mb-0">
                                <thead>
                                    <tr>
                                        <th>Imagem</th>
                                        <th>Produto</th>
                                        <th>Categoria</th>
                                        <th>Preço</th>
                                        <th class="text-center">Ação</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (mysqli_num_rows($ultimos) == 0) { ?>
                                        <tr>
                                            <td colspan="5" class="text-center text-muted py-4">Nenhum produto cadastrado ainda.</td>
                                        </tr>
                                    <?php } else { ?>
                                        <?php while ($p = mysqli_fetch_assoc($ultimos)) { ?>
                                            <tr>
                                                <td>
                                                    <?php if ($p["imagem"] != "") { ?>
                                                        <img src="../imagens/<?php echo htmlspecialchars($p["imagem"]); ?>" class="table-img">
                                                    <?php } else { ?>
                                                        <div class="table-img-placeholder">
                                                            <i class="ph ph-image"></i>
                                                        </div>
                                                    <?php } ?>
                                                </td>
                                                <td>
                                                    <div class="table-product-name"><?php echo htmlspecialchars($p["nome"]); ?></div>
                                                </td>
                                                <td><span class="table-badge"><?php echo htmlspecialchars($p["categoria"]); ?></span></td>
                                                <td class="table-price">R$ <?php echo number_format($p["preco"], 2, ",", "."); ?></td>
                                                <td class="text-center">
                                                    <a href="produtos/form.php?id=<?php echo $p["id"]; ?>" class="table-action-btn">
                                                        <i class="ph ph-pencil-simple"></i> Editar
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php } ?>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/animacoes.js"></script>
</body>
</html>
