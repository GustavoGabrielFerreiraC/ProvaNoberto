<?php
// usuarios/form.php - cadastrar (CREATE) e editar (UPDATE) usuário
$base = "../";
include "../verifica_login.php";
include "../../conexao.php";

$erro = "";
$id = 0;
$nome = "";
$login = "";

// se veio ?id=, é edição: busco os dados pra preencher o formulário
if (isset($_GET["id"])) {
    $id = (int)$_GET["id"];
    $resultado = mysqli_query($conexao, "SELECT * FROM usuarios WHERE id = $id");
    $u = mysqli_fetch_assoc($resultado);
    if ($u) {
        $nome = $u["nome"];
        $login = $u["login"];
    }
}

// quando o formulário é enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // pego os dados que vieram
    $id = (int)$_POST["id"];
    $nome = $_POST["nome"];
    $login = $_POST["login"];
    $senha = $_POST["senha"];

    // escapo os textos antes de jogar no SQL
    $nome_sql = mysqli_real_escape_string($conexao, $nome);
    $login_sql = mysqli_real_escape_string($conexao, $login);

    if ($id == 0) {
        // usuário novo: senha é obrigatória e vai criptografada
        if ($senha == "") {
            $erro = "Digite uma senha.";
        } else {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            $sql = "INSERT INTO usuarios (nome, login, senha) VALUES ('$nome_sql', '$login_sql', '$hash')";
        }
    } else {
        // editando: só troco a senha se digitaram alguma coisa
        if ($senha != "") {
            $hash = password_hash($senha, PASSWORD_DEFAULT);
            $sql = "UPDATE usuarios SET nome='$nome_sql', login='$login_sql', senha='$hash' WHERE id=$id";
        } else {
            $sql = "UPDATE usuarios SET nome='$nome_sql', login='$login_sql' WHERE id=$id";
        }
    }

    if ($erro == "") {
        if (mysqli_query($conexao, $sql)) {
            header("Location: listar.php"); // deu certo: volto pra lista
            exit;
        } else {
            $erro = "Erro ao salvar (esse login já existe?).";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo ($id == 0) ? "Novo usuário" : "Editar usuário"; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../../estilo.css">
</head>
<body class="fundo-ceu">
    <?php include "../../fundo_ceu.php"; ?>
    <?php include "../menu.php"; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="mb-0"><?php echo ($id == 0) ? "Novo usuário" : "Editar usuário"; ?></h1>
            <a href="listar.php" class="btn btn-secondary">← Voltar para lista</a>
        </div>

        <?php if ($erro != "") { ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($erro); ?></div>
        <?php } ?>

        <div class="row">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <form method="post">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            
                            <div class="mb-3">
                                <label for="nome" class="form-label">Nome completo *</label>
                                <input type="text" class="form-control" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="login" class="form-label">Login/Usuário *</label>
                                <input type="text" class="form-control" id="login" name="login" value="<?php echo htmlspecialchars($login); ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="senha" class="form-label">Senha <?php if ($id > 0) echo "(deixe vazio para manter a atual)"; ?><?php if ($id == 0) echo " *"; ?></label>
                                <input type="password" class="form-control" id="senha" name="senha" <?php if ($id == 0) echo "required"; ?>>
                            </div>

                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">Salvar</button>
                                <a href="listar.php" class="btn btn-outline-secondary">Cancelar</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/animacoes.js"></script>
</body>
</html>
