<?php
// usuarios/listar.php - mostra os usuários e apaga quando clico em excluir
$base = "../";
include "../verifica_login.php";
include "../../conexao.php";

$msg = "";

// se veio ?excluir=ID na URL, apago o usuário
if (isset($_GET["excluir"])) {
    $id = (int)$_GET["excluir"];
    if ($id == $_SESSION["usuario_id"]) {
        $msg = "Você não pode excluir o usuário que está logado.";
    } else {
        mysqli_query($conexao, "DELETE FROM usuarios WHERE id = $id");
        $msg = "Usuário excluído!";
    }
}

// busco todos os usuários 
$resultado = mysqli_query($conexao, "SELECT * FROM usuarios ORDER BY nome");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuários</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../../estilo.css">
</head>
<body class="fundo-ceu">
    <?php include "../../fundo_ceu.php"; ?>
    <?php include "../menu.php"; ?>
    
    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="mb-0">Usuários</h1>
            <a href="form.php" class="btn btn-primary"><i class="bi bi-person-plus me-1"></i> Novo usuário</a>
        </div>

        <?php if ($msg != "") { ?>
            <div class="alert alert-info alert-dismissible fade show">
                <?php echo htmlspecialchars($msg); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php } ?>

        <div class="card shadow-sm border-0">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Login</th>
                                <th class="text-center">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($u = mysqli_fetch_assoc($resultado)) { ?>
                            <tr>
                                <td><?php echo $u["id"]; ?></td>
                                <td><strong><?php echo htmlspecialchars($u["nome"]); ?></strong></td>
                                <td><?php echo htmlspecialchars($u["login"]); ?></td>
                                <td class="text-center">
                                    <a href="form.php?id=<?php echo $u["id"]; ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i> Editar</a>
                                    <a href="listar.php?excluir=<?php echo $u["id"]; ?>" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Excluir</a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/animacoes.js"></script>
</body>
</html>
