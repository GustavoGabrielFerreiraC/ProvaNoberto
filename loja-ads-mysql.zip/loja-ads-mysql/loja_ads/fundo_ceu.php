<!-- fundo_ceu.php - o céu animado que fica atrás de tudo (loja e painel) -->
<div class="ceu-noturno" aria-hidden="true">
    <div class="sky-canvas">
        <div class="stars stars-1"></div>
        <div class="stars stars-2"></div>
        <div class="stars stars-3"></div>

        <div class="meteor m1"></div>
        <div class="meteor m2"></div>
        <div class="meteor m3"></div>

        <div class="moon"></div>
    </div>
</div>
