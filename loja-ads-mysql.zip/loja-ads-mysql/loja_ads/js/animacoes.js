// animacoes.js - as animações da loja
// é tudo DOM na mão: pego os elementos e mudo opacidade e posição
// pra eles aparecerem devagar na tela.

// só mexo na página depois que ela carregou inteira
window.onload = function () {
    animarTitulo();
    animarCards();
};

// o título desce um pouquinho quando a página abre
function animarTitulo() {
    var titulo = document.querySelector(".loja h1");

    if (titulo == null) {
        return;
    }

    titulo.style.opacity = "0";
    titulo.style.marginTop = "0px";
    titulo.style.transition = "opacity 0.8s ease, margin-top 0.8s ease";

    setTimeout(function () {
        titulo.style.opacity = "1";
        titulo.style.marginTop = "30px";
    }, 100);
}

// os cards entram um atrás do outro
function animarCards() {
    var cards = document.querySelectorAll(".produto");

    for (var i = 0; i < cards.length; i++) {
        var card = cards[i];

        card.style.opacity = "0";
        card.style.transform = "translateY(25px)";
        card.style.transition = "opacity 0.5s ease, transform 0.5s ease";

        mostrarCard(card, i + 1);
    }
}

// espero um tempinho a mais pra cada card, senão entra tudo junto
function mostrarCard(card, posicao) {
    setTimeout(function () {
        card.style.opacity = "1";
        card.style.transform = "translateY(0)";
    }, 120 * posicao);
}
